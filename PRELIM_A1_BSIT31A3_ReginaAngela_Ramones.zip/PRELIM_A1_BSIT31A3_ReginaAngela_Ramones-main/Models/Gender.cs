namespace Tester.Models
{
    public enum Gender
    {
        Unknown,
        Male,
        Female
    }
}